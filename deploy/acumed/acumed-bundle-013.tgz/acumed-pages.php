<?php
/**
 * AcuMed staging page builder. Run from the site root with:
 *   wp eval-file acumed-pages.php build     — create/update the block pages from acumed-pages/*.html (publishes them)
 *   wp eval-file acumed-pages.php legal     — copy the four legal pages from live acumedgroup.com as published pages
 *   wp eval-file acumed-pages.php check     — list every expected slug with id, template, parent and URL
 *
 * The page sources live in a sibling folder `acumed-pages/` (one <slug>.html per page). Each file starts with an
 * `<!-- acumed:meta … -->` block giving title, excerpt, template, parent and menu order. Re-running `build` overwrites
 * content, excerpt and template of an existing page with the same slug; it never deletes anything.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
set_time_limit( 0 );

$mode = isset( $args[0] ) ? $args[0] : 'check';
$dir  = dirname( __FILE__ ) . '/acumed-pages';

$expected = array( 'home', 'blog', 'what-we-offer', 'acupuncture', 'cupping', 'medical-massage', 'homeopathic-pain-injections', 'metabolic-support', 'iv-therapy',
	'for-veterans', 'new-patient-center', 'staff', 'contact-us', 'faqs', 'wellness-in-the-workplace',
	'conditions', 'chronic-pain', 'womens-health', 'anxiety-sleep-stress', 'digestive-allergies', 'recovery',
	'privacy-policy', 'terms-and-conditions', 'hipaa-notice', 'medical-disclaimer' );

function am_meta( $src ) {
	$m = array( 'title' => '', 'excerpt' => '', 'template' => '', 'parent' => '', 'order' => 0 );
	if ( preg_match( '/<!--\s*acumed:meta(.*?)-->/s', $src, $mm ) ) {
		foreach ( preg_split( '/\r?\n/', trim( $mm[1] ) ) as $line ) {
			if ( strpos( $line, ':' ) === false ) continue;
			list( $k, $v ) = explode( ':', $line, 2 );
			$m[ trim( $k ) ] = trim( $v );
		}
		$src = preg_replace( '/<!--\s*acumed:meta.*?-->\s*/s', '', $src, 1 );
	}
	return array( $m, $src );
}

function am_find( $slug, $parent_id = 0 ) {
	$q = get_posts( array( 'post_type' => 'page', 'name' => $slug, 'post_status' => 'any', 'posts_per_page' => 1, 'post_parent' => $parent_id, 'fields' => 'ids' ) );
	return $q ? (int) $q[0] : 0;
}

if ( $mode === 'build' ) {
	if ( ! is_dir( $dir ) ) { WP_CLI::error( "missing $dir" ); }
	$files = glob( $dir . '/*.html' );
	$parsed = array();
	foreach ( $files as $f ) {
		list( $meta, $content ) = am_meta( file_get_contents( $f ) );
		$parsed[ basename( $f, '.html' ) ] = array( $meta, $content );
	}
	// Two passes so parents exist before children.
	$ids = array();
	foreach ( array( false, true ) as $children ) {
		foreach ( $parsed as $slug => $pc ) {
			list( $meta, $content ) = $pc;
			$has_parent = $meta['parent'] !== '';
			if ( $has_parent !== $children ) continue;
			$parent_id = $has_parent ? ( isset( $ids[ $meta['parent'] ] ) ? $ids[ $meta['parent'] ] : am_find( $meta['parent'] ) ) : 0;
			if ( $has_parent && ! $parent_id ) { WP_CLI::warning( "$slug: parent {$meta['parent']} not found, skipping" ); continue; }
			$id = am_find( $slug, $parent_id );
			$data = array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_name'    => $slug,
				'post_title'   => $meta['title'] ?: ucwords( str_replace( '-', ' ', $slug ) ),
				'post_content' => $content,
				'post_excerpt' => $meta['excerpt'],
				'post_parent'  => $parent_id,
				'menu_order'   => (int) $meta['order'],
			);
			if ( $id ) { $data['ID'] = $id; $r = wp_update_post( wp_slash( $data ), true ); } else { $r = wp_insert_post( wp_slash( $data ), true ); }
			if ( is_wp_error( $r ) ) { WP_CLI::warning( "$slug: " . $r->get_error_message() ); continue; }
			$id = (int) $r; $ids[ $slug ] = $id;
			if ( $meta['template'] ) update_post_meta( $id, '_wp_page_template', $meta['template'] ); else delete_post_meta( $id, '_wp_page_template' );
			WP_CLI::log( sprintf( '%-28s %s  #%d  %s', $slug, $id === (int) $r && isset( $data['ID'] ) ? 'updated' : 'created', $id, get_permalink( $id ) ) );
		}
	}
	// Reading settings: static front page = home, posts page = blog.
	if ( isset( $ids['home'] ) && isset( $ids['blog'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['home'] );
		update_option( 'page_for_posts', $ids['blog'] );
		WP_CLI::log( 'Reading settings: front = home #' . $ids['home'] . ', posts = blog #' . $ids['blog'] );
	}
	flush_rewrite_rules();
	WP_CLI::success( 'Pages built: ' . count( $ids ) );
}

if ( $mode === 'legal' ) {
	$live = 'https://acumedgroup.com/wp-json/wp/v2/pages?per_page=100&status=publish&_fields=slug,title,content';
	$r = wp_remote_get( $live, array( 'timeout' => 60, 'user-agent' => 'AcuMed staging importer' ) );
	if ( is_wp_error( $r ) ) { WP_CLI::error( $r->get_error_message() ); }
	$pages = json_decode( wp_remote_retrieve_body( $r ), true );
	$want = array( 'privacy-policy' => 'Privacy Policy', 'terms-and-conditions' => 'Terms and Conditions', 'hipaa-notice' => 'HIPAA Notice', 'medical-disclaimer' => 'Medical Disclaimer' );
	$n = 0;
	foreach ( $pages as $p ) {
		if ( ! isset( $want[ $p['slug'] ] ) ) continue;
		$html = $p['content']['rendered'];
		$html = preg_replace( '/\[\/?et_pb_[^\]]*\]/', '', $html );           // Divi shortcodes
		$html = preg_replace( '/<(script|style)\b.*?<\/\1>/is', '', $html );  // inline scripts/styles
		$html = preg_replace( '/\s(class|style|id)="[^"]*"/', '', $html );   // Divi classes
		$html = trim( $html );
		$content = "<!-- wp:html -->\n$html\n<!-- /wp:html -->";
		$id = am_find( $p['slug'] );
		$data = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $p['slug'], 'post_title' => $want[ $p['slug'] ], 'post_content' => $content, 'menu_order' => 90 );
		if ( $id ) { $data['ID'] = $id; $res = wp_update_post( wp_slash( $data ), true ); } else { $res = wp_insert_post( wp_slash( $data ), true ); }
		if ( is_wp_error( $res ) ) { WP_CLI::warning( $p['slug'] . ': ' . $res->get_error_message() ); continue; }
		delete_post_meta( (int) $res, '_wp_page_template' ); // default page template
		$n++; WP_CLI::log( sprintf( '%-24s #%d  %s', $p['slug'], (int) $res, get_permalink( (int) $res ) ) );
	}
	WP_CLI::success( "Legal pages: $n" );
}

if ( $mode === 'check' ) {
	$missing = array();
	foreach ( $expected as $slug ) {
		$q = get_posts( array( 'post_type' => 'page', 'name' => $slug, 'post_status' => 'any', 'posts_per_page' => 1 ) );
		if ( ! $q ) { $missing[] = $slug; WP_CLI::log( sprintf( '%-28s MISSING', $slug ) ); continue; }
		$p = $q[0];
		$tpl = get_post_meta( $p->ID, '_wp_page_template', true ) ?: 'page';
		$par = $p->post_parent ? get_post_field( 'post_name', $p->post_parent ) : '';
		WP_CLI::log( sprintf( '%-28s #%-5d %-8s tpl=%-15s parent=%-11s %s', $slug, $p->ID, $p->post_status, $tpl, $par ?: '-', get_permalink( $p ) ) );
	}
	WP_CLI::log( 'front: ' . get_option( 'show_on_front' ) . ' / page_on_front=' . get_option( 'page_on_front' ) . ' / page_for_posts=' . get_option( 'page_for_posts' ) );
	if ( $missing ) WP_CLI::warning( 'Missing: ' . implode( ', ', $missing ) ); else WP_CLI::success( 'All expected pages exist' );
}
