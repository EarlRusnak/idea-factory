<?php
/**
 * AcuMed staging importer. Run with: wp eval-file acumed-import.php [posts|pages|photos]
 *
 * posts  — pull categories, tags, all posts (published) from live acumedgroup.com REST API,
 *          sideload featured images, keep slugs and dates.
 * pages  — pull live pages as DRAFTS (reference copy for rebuilding in blocks), keep slugs.
 * photos — read photo-urls.txt (name<TAB>url per line), download, resize to 2400/1200 WebP
 *          into the theme's assets/img folder.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
ini_set( 'memory_limit', '768M' );
set_time_limit( 0 );

$mode = isset( $args[0] ) ? $args[0] : 'posts';
$live = 'https://acumedgroup.com/wp-json/wp/v2/';

function am_get( $url ) {
	$r = wp_remote_get( $url, array( 'timeout' => 60, 'user-agent' => 'AcuMed staging importer' ) );
	if ( is_wp_error( $r ) ) { WP_CLI::warning( "GET failed: $url — " . $r->get_error_message() ); return null; }
	$code = wp_remote_retrieve_response_code( $r );
	if ( $code !== 200 ) { WP_CLI::warning( "GET $code: $url" ); return null; }
	return json_decode( wp_remote_retrieve_body( $r ), true );
}

function am_all( $base, $query = '' ) {
	$out = array(); $page = 1;
	while ( true ) {
		$batch = am_get( $base . '?per_page=100&page=' . $page . $query );
		if ( empty( $batch ) ) break;
		$out = array_merge( $out, $batch );
		if ( count( $batch ) < 100 ) break;
		$page++;
	}
	return $out;
}

function am_sideload( $url, $post_id, $alt = '' ) {
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$existing = get_posts( array( 'post_type' => 'attachment', 'meta_key' => '_am_source_url', 'meta_value' => $url, 'fields' => 'ids', 'posts_per_page' => 1 ) );
	if ( $existing ) return (int) $existing[0];
	$id = media_sideload_image( $url, $post_id, null, 'id' );
	if ( is_wp_error( $id ) ) { WP_CLI::warning( "sideload failed: $url — " . $id->get_error_message() ); return 0; }
	update_post_meta( $id, '_am_source_url', $url );
	if ( $alt ) update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return (int) $id;
}

function am_terms( $taxonomy, $live_terms ) {
	$map = array();
	foreach ( $live_terms as $t ) {
		$term = term_exists( $t['slug'], $taxonomy );
		if ( ! $term ) {
			$term = wp_insert_term( html_entity_decode( $t['name'] ), $taxonomy, array( 'slug' => $t['slug'], 'description' => $t['description'] ) );
			if ( is_wp_error( $term ) ) { WP_CLI::warning( "term failed {$t['slug']}: " . $term->get_error_message() ); continue; }
		}
		$map[ $t['id'] ] = (int) $term['term_id'];
	}
	return $map;
}

if ( $mode === 'posts' ) {
	WP_CLI::log( 'Fetching categories and tags…' );
	$cat_map = am_terms( 'category', am_all( $live . 'categories' ) );
	$tag_map = am_terms( 'post_tag', am_all( $live . 'tags' ) );
	WP_CLI::log( 'Fetching posts…' );
	$posts = am_all( $live . 'posts', '&status=publish&_fields=id,slug,date,modified,title,excerpt,content,featured_media,categories,tags' );
	WP_CLI::log( count( $posts ) . ' posts found' );
	$done = 0;
	foreach ( $posts as $p ) {
		if ( get_page_by_path( $p['slug'], OBJECT, 'post' ) ) { $done++; continue; }
		$title = html_entity_decode( $p['title']['rendered'], ENT_QUOTES | ENT_HTML5 );
		// Live titles carry "| AcuMedGroup Kissimmee, FL" SEO suffixes; keep the clean part as the post title.
		$title = preg_replace( '/\s*\|\s*AcuMedGroup.*$/i', '', $title );
		$content = $p['content']['rendered'];
		// Rewrite in-content media URLs to the live host so images keep working until media is moved.
		$content = str_replace( 'https://acumedgroup.com/wp-content/uploads/', 'https://acumedgroup.com/wp-content/uploads/', $content );
		$id = wp_insert_post( array(
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_name'    => $p['slug'],
			'post_title'   => $title,
			'post_content' => $content,
			'post_excerpt' => wp_strip_all_tags( $p['excerpt']['rendered'] ),
			'post_date'    => $p['date'],
			'post_modified'=> $p['modified'],
			'post_category'=> array_values( array_filter( array_map( function ( $c ) use ( $cat_map ) { return isset( $cat_map[ $c ] ) ? $cat_map[ $c ] : 0; }, $p['categories'] ) ) ),
			'tags_input'   => array(),
		), true );
		if ( is_wp_error( $id ) ) { WP_CLI::warning( "post failed {$p['slug']}: " . $id->get_error_message() ); continue; }
		$tag_ids = array_values( array_filter( array_map( function ( $t ) use ( $tag_map ) { return isset( $tag_map[ $t ] ) ? $tag_map[ $t ] : 0; }, $p['tags'] ) ) );
		if ( $tag_ids ) wp_set_post_terms( $id, $tag_ids, 'post_tag' );
		update_post_meta( $id, '_am_live_id', $p['id'] );
		if ( ! empty( $p['featured_media'] ) ) {
			$m = am_get( $live . 'media/' . $p['featured_media'] . '?_fields=source_url,alt_text' );
			if ( $m && ! empty( $m['source_url'] ) ) {
				$aid = am_sideload( $m['source_url'], $id, $m['alt_text'] );
				if ( $aid ) set_post_thumbnail( $id, $aid );
			}
		}
		$done++;
		WP_CLI::log( "[$done] {$p['slug']}" );
	}
	WP_CLI::success( "Posts imported: $done" );
}

if ( $mode === 'pages' ) {
	$pages = am_all( $live . 'pages', '&status=publish&_fields=id,slug,title,excerpt,content,parent' );
	$done = 0;
	foreach ( $pages as $p ) {
		if ( get_page_by_path( $p['slug'], OBJECT, 'page' ) ) { $done++; continue; }
		$title = preg_replace( '/\s*\|\s*AcuMedGroup.*$/i', '', html_entity_decode( $p['title']['rendered'], ENT_QUOTES | ENT_HTML5 ) );
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'draft',
			'post_name'    => $p['slug'],
			'post_title'   => $title,
			'post_content' => "<!-- wp:paragraph --><p><em>Reference copy of the live page, imported " . date( 'Y-m-d' ) . ". Rebuild in blocks, then publish.</em></p><!-- /wp:paragraph -->\n" . wp_strip_all_tags( $p['content']['rendered'], false ),
		), true );
		if ( is_wp_error( $id ) ) { WP_CLI::warning( "page failed {$p['slug']}" ); continue; }
		update_post_meta( $id, '_am_live_id', $p['id'] );
		$done++;
	}
	WP_CLI::success( "Pages imported as drafts: $done" );
}

if ( $mode === 'photos' ) {
	$list = dirname( __FILE__ ) . '/photo-urls.txt';
	if ( ! file_exists( $list ) ) { WP_CLI::error( 'photo-urls.txt missing' ); }
	$dir = get_theme_file_path( 'assets/img' );
	foreach ( file( $list, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) as $line ) {
		list( $name, $url ) = explode( "\t", $line, 2 );
		$tmp = sys_get_temp_dir() . '/' . $name;
		WP_CLI::log( "Downloading $name…" );
		$r = wp_remote_get( $url, array( 'timeout' => 300, 'stream' => true, 'filename' => $tmp ) );
		if ( is_wp_error( $r ) ) { WP_CLI::warning( $r->get_error_message() ); continue; }
		$img = imagecreatefromjpeg( $tmp );
		if ( ! $img ) { WP_CLI::warning( "decode failed $name" ); continue; }
		// honour EXIF orientation
		$exif = @exif_read_data( $tmp );
		if ( ! empty( $exif['Orientation'] ) ) {
			if ( $exif['Orientation'] == 3 ) $img = imagerotate( $img, 180, 0 );
			if ( $exif['Orientation'] == 6 ) $img = imagerotate( $img, -90, 0 );
			if ( $exif['Orientation'] == 8 ) $img = imagerotate( $img, 90, 0 );
		}
		$w = imagesx( $img ); $h = imagesy( $img );
		$base = strtolower( preg_replace( '/\.jpe?g$/i', '', str_replace( array( ' ', '(', ')' ), array( '-', '', '' ), $name ) ) );
		foreach ( array( 2400, 1200 ) as $tw ) {
			if ( $w >= $h ) { $nw = min( $tw, $w ); $nh = (int) round( $h * $nw / $w ); } else { $nh = min( $tw, $h ); $nw = (int) round( $w * $nh / $h ); }
			$out = imagecreatetruecolor( $nw, $nh );
			imagecopyresampled( $out, $img, 0, 0, 0, 0, $nw, $nh, $w, $h );
			$file = "$dir/acumed-$base-$tw.webp";
			imagewebp( $out, $file, 82 );
			imagedestroy( $out );
			WP_CLI::log( "  $file " . round( filesize( $file ) / 1024 ) . ' KB' );
		}
		imagedestroy( $img );
		unlink( $tmp );
	}
	WP_CLI::success( 'Photos processed' );
}
