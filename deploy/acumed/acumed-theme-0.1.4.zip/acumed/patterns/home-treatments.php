<?php
/**
 * Title: Home — treatments grid
 * Slug: acumed/home-treatments
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section" aria-labelledby="am-treat-title">
  <div class="am-wrap">
    <div class="am-section__head">
      <p class="am-eyebrow">Treatments</p>
      <h2 id="am-treat-title" style="margin-top:14px">Four modalities, <em>one treatment plan.</em></h2>
      <p class="am-lede" style="margin-top:14px">Treatments are rarely isolated here. Structural, circulatory and nervous‑system work are combined around the cause of your symptoms, not just the symptom.</p>
      <hr class="am-rule">
    </div>

    <div class="am-treatment-grid">
      <a class="am-treatment-card" href="/acupuncture/">
        <div class="am-treatment-card__image" style="background-image:url('<?php echo acumed_img( 'acumed-dsc01118-1200.webp' ); ?>')"></div>
        <div class="am-treatment-card__eyebrow">Orthopedic · Electro · Dry needling</div>
        <h3 class="am-treatment-card__title">Acupuncture <em>Therapy</em></h3>
        <p class="am-treatment-card__desc">Precise stimulation of the nervous system to relieve pain, regulate stress and trigger the body’s own repair. Three techniques, chosen per diagnosis.</p>
        <div class="am-treatment-card__meta"><span>Learn more</span><span class="am-treatment-card__arrow">→</span></div>
      </a>

      <a class="am-treatment-card" href="/cupping/">
        <div class="am-treatment-card__image am-treatment-card__image--tone"><span>Negative pressure</span></div>
        <div class="am-treatment-card__eyebrow">Fascia &amp; circulation</div>
        <h3 class="am-treatment-card__title">Cupping <em>Therapy</em></h3>
        <p class="am-treatment-card__desc">Suction lifts tissue rather than compressing it, flooding a muscle region with fresh blood flow to reduce pain and speed recovery.</p>
        <div class="am-treatment-card__meta"><span>Learn more</span><span class="am-treatment-card__arrow">→</span></div>
      </a>

      <a class="am-treatment-card" href="/medical-massage/">
        <div class="am-treatment-card__image am-treatment-card__image--tone"><span>Physician‑directed</span></div>
        <div class="am-treatment-card__eyebrow">Prescribed conditions</div>
        <h3 class="am-treatment-card__title">Medical <em>Massage</em></h3>
        <p class="am-treatment-card__desc">Not a spa massage. Targeted manual work on the structures named in your diagnosis, by a licensed therapist with a physiotherapy background.</p>
        <div class="am-treatment-card__meta"><span>Learn more</span><span class="am-treatment-card__arrow">→</span></div>
      </a>

      <a class="am-treatment-card" href="/homeopathic-pain-injections/">
        <div class="am-treatment-card__image" style="background-image:url('<?php echo acumed_img( 'acumed-treatment-room-1200.webp' ); ?>')"></div>
        <div class="am-treatment-card__eyebrow">Pain · Energy · Metabolic</div>
        <h3 class="am-treatment-card__title">Medical <em>Injections</em></h3>
        <p class="am-treatment-card__desc">Homeopathic pain injections for chronic pain and fatigue, B‑12 and lipotropic shots, and physician‑guided IV nutrient infusions.</p>
        <div class="am-treatment-card__meta"><span>Learn more</span><span class="am-treatment-card__arrow">→</span></div>
      </a>
    </div>
  </div>
</section>
<!-- /wp:html -->
