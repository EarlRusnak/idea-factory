<?php
/**
 * Title: Home — conditions we treat
 * Slug: acumed/home-conditions
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section" style="background:var(--wp--preset--color--white)" aria-labelledby="am-cond-title">
  <div class="am-wrap">
    <div class="am-section__head">
      <p class="am-eyebrow">Conditions</p>
      <h2 id="am-cond-title" style="margin-top:14px">You may consider acupuncture if you are <em>living with:</em></h2>
      <hr class="am-rule">
    </div>

    <div class="am-conditions">
      <a class="am-condition" href="/conditions/chronic-pain/">
        <h3 class="am-condition__title">Chronic pain</h3>
        <p class="am-condition__list">Back and neck pain, sciatica, migraines, joint discomfort, arthritis, soft‑tissue injury.</p>
        <span class="am-condition__link">How we treat it →</span>
      </a>
      <a class="am-condition" href="/conditions/womens-health/">
        <h3 class="am-condition__title">Women’s health</h3>
        <p class="am-condition__list">Menstrual problems, fertility support, perimenopause and menopause symptoms.</p>
        <span class="am-condition__link">How we treat it →</span>
      </a>
      <a class="am-condition" href="/conditions/anxiety-sleep-stress/">
        <h3 class="am-condition__title">Anxiety, sleep &amp; stress</h3>
        <p class="am-condition__list">Low mood, insomnia, fatigue and the stress cycles that keep pain from settling.</p>
        <span class="am-condition__link">How we treat it →</span>
      </a>
      <a class="am-condition" href="/conditions/digestive-allergies/">
        <h3 class="am-condition__title">Digestive &amp; allergies</h3>
        <p class="am-condition__list">Nausea, IBS, bloating, acid reflux, seasonal allergies and sinus congestion.</p>
        <span class="am-condition__link">How we treat it →</span>
      </a>
      <a class="am-condition" href="/conditions/recovery/">
        <h3 class="am-condition__title">Post‑surgical &amp; trauma recovery</h3>
        <p class="am-condition__list">Tension and inflammation after surgery or injury. PTSD and TBI support for veterans.</p>
        <span class="am-condition__link">How we treat it →</span>
      </a>
      <a class="am-condition" href="/conditions/">
        <h3 class="am-condition__title">Something else?</h3>
        <p class="am-condition__list">Allergies, asthma, hypertension, tobacco cessation, morning sickness and more. See the full list.</p>
        <span class="am-condition__link">All conditions →</span>
      </a>
    </div>
  </div>
</section>
<!-- /wp:html -->
