<?php
/**
 * Title: CTA panel — dark
 * Slug: acumed/cta
 * Categories: acumed
 * Inserter: yes
 */
$c = acumed_clinic();
?>
<!-- wp:html -->
<section class="am-cta am-on-dark" aria-labelledby="am-cta-title">
  <p class="am-eyebrow">Begin your healing journey</p>
  <h2 id="am-cta-title" style="margin-top:20px">Heal deeper. Restore balance. <em>Reclaim your wellness.</em></h2>
  <p>Tell us what you are dealing with. A member of our clinical team reviews every request and calls you within one business day to confirm the right treatment and book your first visit with Dr. Rusnak. Veterans: ask about VA Community Care authorization.</p>
  <div class="wp-block-buttons" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center">
    <div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $c['booking'] ); ?>">Request an appointment</a></div>
    <div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:<?php echo esc_attr( $c['tel'] ); ?>">Call <?php echo esc_html( $c['phone'] ); ?></a></div>
  </div>
</section>
<!-- /wp:html -->
