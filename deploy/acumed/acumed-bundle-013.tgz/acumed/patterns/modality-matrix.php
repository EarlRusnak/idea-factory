<?php
/**
 * Title: Modality matrix table
 * Slug: acumed/modality-matrix
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section am-section--tight" aria-labelledby="am-matrix-title">
  <div class="am-wrap">
    <div class="am-section__head">
      <p class="am-eyebrow">The modality matrix</p>
      <h2 id="am-matrix-title" style="margin-top:14px">How each treatment <em>works.</em></h2>
      <hr class="am-rule">
    </div>
    <div class="am-matrix-wrap">
      <table class="am-matrix">
        <thead><tr><th scope="col">Treatment</th><th scope="col">Mechanism</th><th scope="col">Target system</th><th scope="col">Primary benefit</th></tr></thead>
        <tbody>
          <tr><th scope="row">Acupuncture</th><td>Needle stimulation of specific points</td><td>Central nervous system and meridians</td><td>Relieves pain and stress, triggers natural healing and endorphin release</td></tr>
          <tr><th scope="row">Cupping</th><td>Negative pressure, tissue lift</td><td>Fascia and circulatory pathways</td><td>Increases local blood flow, aids detoxification, relaxes muscle</td></tr>
          <tr><th scope="row">Medical massage</th><td>Physician‑directed manual pressure</td><td>Musculoskeletal structure</td><td>Resolves specific diagnosed conditions through targeted manipulation</td></tr>
          <tr><th scope="row">Homeopathic injections</th><td>Subcutaneous delivery</td><td>Systemic and cellular response</td><td>Natural alternative for chronic pain, low mood and fatigue</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- /wp:html -->
