<?php
/**
 * Title: Ecosystem strip — the four Rusnak brands
 * Slug: acumed/ecosystem
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-ecosystem" aria-labelledby="am-eco-title">
  <div class="am-ecosystem__head">
    <p class="am-eyebrow">Dr. Rusnak’s 360° healing ecosystem</p>
    <h2 id="am-eco-title" style="margin-top:12px">Internal healing, external restoration, <em>long‑term wellness.</em></h2>
    <p>Four practices under one clinician. AcuMedGroup is where the journey starts.</p>
  </div>
  <div class="am-ecosystem__grid">
    <a class="am-ecosystem__card is-current" href="/" aria-current="page">
      <span class="am-ecosystem__step">Internal healing</span>
      <span class="am-ecosystem__name">AcuMedGroup</span>
      <span class="am-ecosystem__desc">Clinical acupuncture and integrative medicine in Kissimmee.</span>
    </a>
    <a class="am-ecosystem__card" href="https://healing-skin.com/" rel="noopener">
      <span class="am-ecosystem__step">External restoration</span>
      <span class="am-ecosystem__name">Healing Skin</span>
      <span class="am-ecosystem__desc">Paramedical tattoo, scar camouflage and 3D areola restoration.</span>
    </a>
    <a class="am-ecosystem__card" href="https://drrusnakacademy.com/" rel="noopener">
      <span class="am-ecosystem__step">Training</span>
      <span class="am-ecosystem__name">Dr. Rusnak Academy</span>
      <span class="am-ecosystem__desc">Professional paramedical tattoo training and certification.</span>
    </a>
    <a class="am-ecosystem__card" href="https://drrusnakwellness.com/" rel="noopener">
      <span class="am-ecosystem__step">Long‑term care</span>
      <span class="am-ecosystem__name">Dr. Rusnak Wellness</span>
      <span class="am-ecosystem__desc">Medical‑grade skincare and scar care products.</span>
    </a>
  </div>
</section>
<!-- /wp:html -->
