<?php
// Standalone (no WordPress). Usage: php resize-photos.php photo-urls.txt /abs/path/to/theme/assets/img
// photo-urls.txt: one "name<TAB>url" per line. Downloads each JPG, honours EXIF orientation,
// writes acumed-<base>-2400.webp and acumed-<base>-1200.webp into the target dir.
ini_set('memory_limit', '1024M');
set_time_limit(0);
$list = $argv[1] ?? 'photo-urls.txt';
$dir  = rtrim($argv[2] ?? '.', '/');
if (!is_dir($dir)) { fwrite(STDERR, "no dir $dir\n"); exit(1); }
foreach (file($list, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
    [$name, $url] = array_pad(explode("\t", $line, 2), 2, '');
    if ($url === '') continue;
    $tmp = sys_get_temp_dir() . '/' . preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
    echo "Downloading $name…\n";
    $in = fopen($url, 'rb'); if (!$in) { echo "  download failed\n"; continue; }
    $out = fopen($tmp, 'wb'); stream_copy_to_stream($in, $out); fclose($in); fclose($out);
    $img = @imagecreatefromjpeg($tmp);
    if (!$img) { echo "  decode failed\n"; continue; }
    $exif = @exif_read_data($tmp);
    if (!empty($exif['Orientation'])) {
        if ($exif['Orientation'] == 3) $img = imagerotate($img, 180, 0);
        if ($exif['Orientation'] == 6) $img = imagerotate($img, -90, 0);
        if ($exif['Orientation'] == 8) $img = imagerotate($img, 90, 0);
    }
    $w = imagesx($img); $h = imagesy($img);
    $base = strtolower(preg_replace('/\.jpe?g$/i', '', str_replace([' ', '(', ')'], ['-', '', ''], $name)));
    foreach ([2400, 1200] as $t) {
        if ($w >= $h) { $nw = min($t, $w); $nh = (int) round($h * $nw / $w); } else { $nh = min($t, $h); $nw = (int) round($w * $nh / $h); }
        $o = imagecreatetruecolor($nw, $nh);
        imagecopyresampled($o, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
        $f = "$dir/acumed-$base-$t.webp";
        imagewebp($o, $f, 82); imagedestroy($o);
        echo "  $f " . round(filesize($f) / 1024) . " KB\n";
    }
    imagedestroy($img); unlink($tmp);
}
echo "PHOTOS-OK\n";
