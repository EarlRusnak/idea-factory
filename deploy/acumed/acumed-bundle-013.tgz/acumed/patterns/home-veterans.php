<?php
/**
 * Title: Veterans panel
 * Slug: acumed/veterans
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-veterans" aria-labelledby="am-vet-title">
  <div>
    <p class="am-eyebrow">For veterans · VA Community Care</p>
    <h2 id="am-vet-title">Thank you for your service. <em>Now let us serve you.</em></h2>
    <p style="color:var(--wp--preset--color--gray-700);line-height:1.7;max-width:52ch">When standard treatment has stalled, acupuncture gives veterans a drug‑free path for chronic pain, PTSD and TBI symptoms. AcuMedGroup is an approved VA Community Care provider, so your care can be authorized through the VA.</p>
    <ul>
      <li>Referral and authorization handled with your VA care team</li>
      <li>Weekly sessions with progress notes submitted for you</li>
      <li>Pain, sleep, stress and inflammation addressed together</li>
    </ul>
    <div class="wp-block-buttons">
      <div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/for-veterans/">How VA‑covered care works</a></div>
    </div>
  </div>
  <div class="am-veterans__photo" role="img" aria-label="Practitioner in gloves placing acupuncture needles along a patient's leg" style="background-image:url('<?php echo acumed_img( 'acumed-dsc01121-1200.webp' ); ?>')"></div>
</section>
<!-- /wp:html -->
