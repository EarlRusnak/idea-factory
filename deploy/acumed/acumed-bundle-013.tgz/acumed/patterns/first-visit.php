<?php
/**
 * Title: Your first visit — five steps
 * Slug: acumed/first-visit
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section" id="first-visit" aria-labelledby="am-visit-title">
  <div class="am-wrap">
    <div class="am-section__head">
      <p class="am-eyebrow">Your first visit</p>
      <h2 id="am-visit-title" style="margin-top:14px">Every patient is reviewed first. <em>Then the healing begins.</em></h2>
      <hr class="am-rule">
    </div>
    <div class="am-steps">
      <div class="am-step"><h3>Screening call</h3><p>Send an appointment request. A member of our clinical team calls within one business day to review your concern, confirm that acupuncture or another modality is the right fit, and book your first visit.</p></div>
      <div class="am-step"><h3>Consultation</h3><p>A detailed review of your history and current symptoms. Tongue and pulse examination, per traditional diagnostics.</p></div>
      <div class="am-step"><h3>Needle placement</h3><p>Thin, sterile, single‑use needles at specific points. You may feel a slight pinch or a dull pressure.</p></div>
      <div class="am-step"><h3>Retention</h3><p>Needles stay in place for 15 to 30 minutes while you rest and breathe. Many patients fall asleep.</p></div>
      <div class="am-step"><h3>Removal</h3><p>Needles are removed gently. Cupping or manual work may follow, depending on your plan.</p></div>
      <div class="am-step"><h3>Your plan</h3><p>Exercises, dietary changes or lifestyle adjustments to hold the benefit between sessions.</p></div>
    </div>
  </div>
</section>
<!-- /wp:html -->
