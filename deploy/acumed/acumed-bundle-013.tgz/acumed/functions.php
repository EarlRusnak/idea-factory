<?php
/**
 * AcuMedGroup block theme — functions.
 *
 * Forked from the Healing Skin theme so both sites share one design system.
 * Keep this file small: fonts, one stylesheet, one script, patterns, schema.
 */

defined( 'ABSPATH' ) || exit;

define( 'ACUMED_VERSION', '0.1.3' );

/* ---------------------------------------------------------------------
 * Theme setup
 * ------------------------------------------------------------------ */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 360, 'flex-height' => true, 'flex-width' => true ) );
	add_editor_style( array( acumed_fonts_url(), 'assets/css/app.css' ) );
	remove_theme_support( 'core-block-patterns' );
} );

/* ---------------------------------------------------------------------
 * Fonts — Fraunces (display) + Instrument Sans (body), one request.
 * ------------------------------------------------------------------ */
function acumed_fonts_url() {
	$families = array(
		'Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,300;1,9..144,400;1,9..144,500',
		'Instrument+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500',
	);
	return 'https://fonts.googleapis.com/css2?family=' . implode( '&family=', $families ) . '&display=swap';
}

/* ---------------------------------------------------------------------
 * Assets
 * ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'acumed-fonts', acumed_fonts_url(), array(), null );
	wp_enqueue_style( 'acumed-app', get_theme_file_uri( 'assets/css/app.css' ), array(), ACUMED_VERSION );
	wp_enqueue_script( 'acumed-nav', get_theme_file_uri( 'assets/js/nav.js' ), array(), ACUMED_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
} );

add_action( 'wp_head', function () {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 1 );

/* Trim WordPress defaults we do not use. */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );
add_filter( 'emoji_svg_url', '__return_false' );

/* ---------------------------------------------------------------------
 * Block patterns
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	register_block_pattern_category( 'acumed', array( 'label' => 'AcuMedGroup' ) );
} );

/* ---------------------------------------------------------------------
 * Block styles
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	register_block_style( 'core/button', array( 'name' => 'outline', 'label' => 'Outline' ) );
	register_block_style( 'core/button', array( 'name' => 'cinnabar', 'label' => 'Cinnabar' ) );
	register_block_style( 'core/button', array( 'name' => 'on-dark', 'label' => 'On dark' ) );
} );

/* ---------------------------------------------------------------------
 * Helpers used by patterns
 * ------------------------------------------------------------------ */
function acumed_img( $file ) {
	return esc_url( get_theme_file_uri( 'assets/img/' . ltrim( $file, '/' ) ) );
}

/**
 * Clinic facts in one place. Patterns and schema read from here.
 */
function acumed_clinic() {
	return array(
		'name'     => 'AcuMedGroup Wellness Center',
		'phone'    => '(407) 624-5258',
		'tel'      => '+14076245258',
		'email'    => 'clinic@acumedgroup.com',
		'street'   => '1107 Person Street',
		'city'     => 'Kissimmee',
		'region'   => 'FL',
		'zip'      => '34741',
		'booking'  => '/contact-us/#book', // Appointment REQUEST form (GHL). Never a public Jane App link: Dr. Cecilia books only patients screened by staff (decision Sep 7, 2026).
		'maps'     => 'https://maps.google.com/?q=AcuMedGroup+Wellness+Center+1107+Person+Street+Kissimmee+FL+34741',
	);
}

/* ---------------------------------------------------------------------
 * Structured data — MedicalClinic + Physician, sitewide.
 * ------------------------------------------------------------------ */
add_action( 'wp_head', function () {
	$c = acumed_clinic();
	$schema = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'     => array( 'MedicalClinic', 'LocalBusiness' ),
				'@id'       => home_url( '/#clinic' ),
				'name'      => $c['name'],
				'url'       => home_url( '/' ),
				'telephone' => $c['tel'],
				'email'     => $c['email'],
				'image'     => acumed_img( 'acumed-dsc01128-edited-2400.webp' ),
				'address'   => array(
					'@type'           => 'PostalAddress',
					'streetAddress'   => $c['street'],
					'addressLocality' => $c['city'],
					'addressRegion'   => $c['region'],
					'postalCode'      => $c['zip'],
					'addressCountry'  => 'US',
				),
				'geo'       => array( '@type' => 'GeoCoordinates', 'latitude' => 28.3019877, 'longitude' => -81.414668 ),
				'medicalSpecialty' => array( 'Acupuncture', 'IntegrativeMedicine' ),
					'openingHoursSpecification' => array(
						array( '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday' ), 'opens' => '09:00', 'closes' => '18:00' ),
						array( '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => 'Thursday', 'opens' => '09:00', 'closes' => '13:00' ),
					),
				'availableService' => array(
					array( '@type' => 'MedicalTherapy', 'name' => 'Acupuncture' ),
					array( '@type' => 'MedicalTherapy', 'name' => 'Electroacupuncture' ),
					array( '@type' => 'MedicalTherapy', 'name' => 'Dry Needling' ),
					array( '@type' => 'MedicalTherapy', 'name' => 'Cupping Therapy' ),
					array( '@type' => 'MedicalTherapy', 'name' => 'Medical Massage' ),
					array( '@type' => 'MedicalTherapy', 'name' => 'Homeopathic Pain Injections' ),
						array( '@type' => 'MedicalTherapy', 'name' => 'IV Nutrient Therapy' ),
				),
				'founder'   => array( '@id' => home_url( '/#dr-rusnak' ) ),
				'sameAs'    => array(
					'https://www.facebook.com/acumedgroup',
					'https://www.instagram.com/acumedgroup/',
					'https://x.com/AcuMedGroup',
					'https://healing-skin.com/',
					'https://drrusnakacademy.com/',
					'https://drrusnakwellness.com/',
				),
			),
			array(
				'@type'    => 'Physician',
				'@id'      => home_url( '/#dr-rusnak' ),
				'name'     => 'Dr. Cecilia Rusnak',
				'honorificSuffix' => 'LME, AP, DAc',
				'jobTitle' => 'Acupuncture Physician',
				'worksFor' => array( '@id' => home_url( '/#clinic' ) ),
				'url'      => home_url( '/staff/' ),
			),
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}, 20 );

/* ---------------------------------------------------------------------
 * Excerpt tuning for the journal index.
 * ------------------------------------------------------------------ */
add_filter( 'excerpt_length', function () { return 32; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/* ---------------------------------------------------------------------
 * Legacy URL redirects (301). Every live acumedgroup.com URL that the
 * rebuild retires or merges. Kept in the theme so the map survives the
 * staging → GHL migration without a plugin. Exact path match, trailing
 * slash optional. Edit the array; nothing else to configure.
 * ------------------------------------------------------------------ */
function acumed_redirect_map() {
	return array(
		'/home'                                  => '/',
		'/b-12-injections-2'                     => '/metabolic-support/',
		'/lipotropic-injections'                 => '/metabolic-support/',
		'/semaglutide'                           => '/what-we-offer/',
		'/compounded-medications'                => '/what-we-offer/',
		'/compounded-liraglutide'                => '/what-we-offer/',
		'/glutathione-injections'                => '/what-we-offer/',
		'/memberships'                           => '/new-patient-center/#insurance',
		'/thank-you-for-applying-to-our-program' => '/',
		'/hippa-notice'                          => '/hipaa-notice/',
		'/classes'                               => 'https://drrusnakacademy.com/',
		'/shop'                                  => 'https://drrusnakwellness.com/',
		'/cart'                                  => 'https://drrusnakwellness.com/',
		'/checkout'                              => 'https://drrusnakwellness.com/',
		'/my-account'                            => 'https://drrusnakwellness.com/',
		'/product-category'                      => 'https://drrusnakwellness.com/',
	);
}
add_action( 'template_redirect', function () {
	if ( is_admin() ) return;
	$path = rtrim( wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
	if ( $path === '' ) return;
	$map = acumed_redirect_map();
	foreach ( $map as $from => $to ) {
		if ( $path === $from || strpos( $path, $from . '/' ) === 0 ) {
			wp_redirect( ( strpos( $to, 'http' ) === 0 ? $to : home_url( $to ) ), 301 );
			exit;
		}
	}
}, 1 );
