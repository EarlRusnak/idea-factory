<?php
/**
 * Title: Home — Dr. Rusnak block
 * Slug: acumed/home-founder
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section" aria-labelledby="am-founder-title">
  <div class="am-wrap--wide">
    <div class="am-founder">
      <div class="am-founder__photo" role="img" aria-label="Dr. Cecilia Rusnak, founder of AcuMedGroup Wellness Center" style="background-image:url('<?php echo acumed_img( 'acumed-dr-rusnak-portrait-1200.webp' ); ?>')"></div>
      <div>
        <p class="am-eyebrow">Founder · Acupuncture Physician</p>
        <h2 id="am-founder-title" style="margin:14px 0 6px">Dr. Cecilia <em>Rusnak.</em></h2>
        <p style="font-size:18px;color:var(--wp--preset--color--gray-500);margin:0 0 28px">LME · AP · DAc · Doctor of Acupuncture, Pacific College of Health and Science</p>
        <p class="am-founder-quote">“We unite the time‑tested wisdom of Eastern medicine with the precision of modern wellness science.”</p>
        <p style="line-height:1.75;color:var(--wp--preset--color--gray-700);margin:0 0 20px">State‑licensed Acupuncture Physician. Clinical internship at Yunnan University of Traditional Chinese Medicine, with advanced study in tongue and pulse diagnosis at Kunming Yuan An Hospital. Founder of Healing Skin Medical Aesthetics and Dr. Rusnak Academy, and creator of the Dr. Rusnak Wellness skincare line.</p>
        <p style="font-weight:600;letter-spacing:0.02em;margin:0"><a href="/staff/">Meet Dr. Rusnak and the team →</a></p>
      </div>
    </div>
  </div>
</section>
<!-- /wp:html -->
