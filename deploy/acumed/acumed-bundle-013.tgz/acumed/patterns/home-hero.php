<?php
/**
 * Title: Home hero — dark, photo right
 * Slug: acumed/home-hero
 * Categories: acumed
 * Inserter: yes
 */
$c = acumed_clinic();
?>
<!-- wp:html -->
<section class="am-hero am-on-dark" aria-label="Introduction">
  <div class="am-hero__copy">
    <p class="am-eyebrow am-eyebrow--with-rule">Integrative medicine · Kissimmee Medical Arts District</p>
    <h1 style="margin-top:20px">Healing that starts <em>within.</em></h1>
    <p class="am-hero__lede">Clinical acupuncture, cupping, medical massage and homeopathic injections, planned around your diagnosis by Dr. Cecilia Rusnak, AP, DAc. VA Community Care accepted.</p>
    <div class="wp-block-buttons" style="display:flex;gap:12px;flex-wrap:wrap">
      <div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $c['booking'] ); ?>">Request an appointment</a></div>
      <div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/for-veterans/">Veterans start here</a></div>
    </div>
    <div class="am-hero__proof">
      <span><strong>Doctor of Acupuncture</strong> · Pacific College</span>
      <span><strong>VA Community Care</strong> provider</span>
      <span><strong>Since 2013</strong> in Kissimmee</span>
    </div>
  </div>
  <div class="am-hero__photo" role="img" aria-label="Electroacupuncture treatment on a patient's forearm under red lamp light at AcuMedGroup" style="background-image:url('<?php echo acumed_img( 'acumed-dsc01128-edited-2400.webp' ); ?>')"></div>
</section>
<!-- /wp:html -->
