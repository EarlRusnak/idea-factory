<?php
/**
 * Title: Testimonial pull quote
 * Slug: acumed/testimonial
 * Categories: acumed
 * Inserter: yes
 */
?>
<!-- wp:html -->
<section class="am-section am-section--tight" style="background:var(--wp--preset--color--white)" aria-label="Patient review">
  <div class="am-pullquote">
    <div class="am-pullquote__mark">“</div>
    <p class="am-pullquote__text">Best kept secret in Kissimmee. Dr. Rusnak makes you feel extremely comfortable and like part of the family. She has a gentle touch for those beginners.</p>
    <div class="am-pullquote__author">— Marie N. · Patient · Google review</div>
  </div>
</section>
<!-- /wp:html -->
